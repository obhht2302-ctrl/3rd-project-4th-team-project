# 통합 민원 에이전트 참고 CSV

2026-10-07 공식 출처 조사 결과입니다. 6개 CSV, 총 74행이며 UTF-8 BOM으로 저장했습니다. 파일 수를 늘리기 위한 유형별 복제 대신 서로 다른 용도의 자료로 구성했습니다.

| 파일 | 행 | 활용 |
|---|---:|---|
| `department_contacts.csv` | 8 | 담당 부서·대표전화·상담의 역할 구분 |
| `dongjak_administrative_dongs.csv` | 15 | 동작구 행정동 이름 확인; 법정동/경계/행정코드 아님 |
| `submission_requirements.csv` | 14 | 접수 안내·특정 절차의 요건·프로젝트 권장항목 |
| `complaint_writing_guides.csv` | 12 | 사용자 관찰 사실로 초안을 작성하는 프로젝트 제안 |
| `official_resource_catalog.csv` | 16 | 공식 안내·지도·공공데이터·조사 후보 목록 |
| `research_backlog.csv` | 9 | 아직 검증하지 못한 내용을 조사할 과제 |

현재 locator는 상위 폴더의 `channels.csv`, `integrated_channels.csv`만 자동 적재합니다. 이 폴더는 바로 `channels`에 넣을 자료가 아니며, backend/RAG 담당자가 용도와 제한을 읽고 별도 활용할 수 있도록 준비한 것입니다. `mock_contacts.csv`는 PL의 가상 발송용 자료입니다.

해석 규칙:

- `official_required`는 해당 `channel_scope`와 `applicability`에서만 공식 필수로 해석합니다. 무단투기 포상금의 기한·행위자 정보·방문/우편 제출을 일반 청소요청에 적용하지 않습니다.
- `official_guidance`는 기관 안내, `project_recommendation`은 프로젝트 제안입니다. 제안의 `source_url`은 배경자료이며 같은 문장이 기관 원문에 있다는 뜻이 아닙니다.
- `categories`의 `|`는 여러 유형, `all`은 공통 항목입니다. 운영 API의 category enum과 혼동하지 않습니다.
- `verified_at`은 출처를 확인한 날짜입니다. 원자료의 최신성·전화 연결 성공·접수 완료·실시간 상태를 보장하지 않습니다. 원문이 오래됐거나 충돌하면 `limitations`에 기록했습니다.
- 데이터 목록에는 원자료 자체가 없습니다. 보안등 IoT·CCTV 위치를 현재 고장이나 무단투기 발생의 증거로 사용하지 않습니다.
- 공개 유사 민원의 본문과 처리결과를 함께 검증하지 못해 사례 CSV는 생성하지 않았습니다. 감시단 자격이 불명확한 365안심동작도 추천 창구로 승격하지 않았습니다.
- RAG에 넣을 때 `usage`, `limitations`, 출처와 근거 종류를 함께 보존하고, backlog의 질문을 사실 답변으로 검색하지 않도록 구분합니다.
